import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/auth/presentation/login_screen.dart';
import '../features/customers/presentation/customer_detail_screen.dart';
import '../features/customers/presentation/customer_list_screen.dart';
import '../features/dashboard/presentation/dashboard_screen.dart';
import '../features/readings/presentation/photo_capture_screen.dart';
import '../features/readings/presentation/reading_entry_screen.dart';
import '../features/settings/presentation/settings_screen.dart';
import '../features/sync/presentation/queue_monitor_screen.dart';
import '../features/sync/presentation/sync_center_screen.dart';
import 'providers.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/login',
    redirect: (context, state) {
      final loggedIn = ref.read(authStateProvider);
      final onLogin = state.matchedLocation == '/login';
      if (!loggedIn && !onLogin) return '/login';
      if (loggedIn && onLogin) return '/dashboard';
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (context, state) => const LoginScreen()),
      GoRoute(path: '/dashboard', builder: (context, state) => const DashboardScreen()),
      GoRoute(path: '/customers', builder: (context, state) => const CustomerListScreen()),
      GoRoute(
        path: '/customers/:id',
        builder: (context, state) => CustomerDetailScreen(assignmentId: state.pathParameters['id']!),
      ),
      GoRoute(
        path: '/readings/new/:assignmentId',
        builder: (context, state) => ReadingEntryScreen(assignmentId: state.pathParameters['assignmentId']!),
      ),
      GoRoute(path: '/readings/photo', builder: (context, state) => const PhotoCaptureScreen()),
      GoRoute(path: '/sync', builder: (context, state) => const SyncCenterScreen()),
      GoRoute(path: '/sync/queue', builder: (context, state) => const QueueMonitorScreen()),
      GoRoute(path: '/settings', builder: (context, state) => const SettingsScreen()),
    ],
  );
});
