import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:uuid/uuid.dart';

import '../../../app/providers.dart';
import '../../../shared/widgets/state_widgets.dart';
import '../../customers/domain/entities.dart';
import '../domain/reading.dart';

class ReadingEntryScreen extends ConsumerStatefulWidget {
  final String assignmentId;
  const ReadingEntryScreen({super.key, required this.assignmentId});

  @override
  ConsumerState<ReadingEntryScreen> createState() => _ReadingEntryScreenState();
}

class _ReadingEntryScreenState extends ConsumerState<ReadingEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _valueCtrl = TextEditingController();
  final _remarksCtrl = TextEditingController();
  final _uuid = const Uuid();
  String? _imagePath;
  bool _estimated = false;
  bool _saving = false;

  @override
  Widget build(BuildContext context) {
    final assignments = ref.watch(assignmentsProvider(const AssignmentQuery()));

    return Scaffold(
      appBar: AppBar(title: const Text('إدخال القراءة')),
      body: assignments.when(
        loading: () => const LoadingState(),
        error: (e, _) => ErrorState(message: '$e'),
        data: (list) {
          final match = list.where((a) => a.id == widget.assignmentId);
          if (match.isEmpty) {
            return const EmptyState(icon: Icons.error_outline, title: 'المهمة غير موجودة');
          }
          final assignment = match.first;
          final previous = assignment.customer.lastReadingValue ?? 0;

          return Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.person_outline),
                    title: Text(assignment.customer.name),
                    subtitle: Text('عداد ${assignment.meter.meterNumber} · حساب ${assignment.customer.accountNumber}'),
                  ),
                ),
                const SizedBox(height: 16),
                Text('القراءة السابقة: ${previous.toStringAsFixed(0)} kWh', style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _valueCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700),
                  decoration: const InputDecoration(labelText: 'القراءة الحالية (kWh)'),
                  validator: (v) {
                    if (v == null || v.isEmpty) return 'أدخل القراءة';
                    final val = double.tryParse(v);
                    if (val == null) return 'قيمة غير صالحة';
                    if (val < previous) return 'القراءة أقل من القراءة السابقة — تحقق من الرقم';
                    return null;
                  },
                  onChanged: (_) => setState(() {}),
                ),
                if (_consumptionHint(previous) != null) ...[
                  const SizedBox(height: 8),
                  _ConsumptionHintBanner(text: _consumptionHint(previous)!),
                ],
                const SizedBox(height: 16),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _estimated,
                  onChanged: (v) => setState(() => _estimated = v),
                  title: const Text('قراءة تقديرية'),
                  subtitle: const Text('استخدم فقط عند تعذر الوصول الفعلي للعداد'),
                ),
                const SizedBox(height: 8),
                _PhotoPicker(
                  imagePath: _imagePath,
                  onCapture: () => _openCamera(),
                  onClear: () => setState(() => _imagePath = null),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _remarksCtrl,
                  maxLines: 2,
                  decoration: const InputDecoration(labelText: 'ملاحظات (اختياري)'),
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _saving ? null : () => _submit(assignment),
                  child: _saving
                      ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                      : const Text('حفظ وإرسال للمزامنة'),
                ),
                const SizedBox(height: 8),
                Text(
                  'ستُحفظ القراءة محلياً فوراً وتُرفع تلقائياً عند توفر الاتصال.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).colorScheme.outline),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  String? _consumptionHint(double previous) {
    final val = double.tryParse(_valueCtrl.text);
    if (val == null || previous <= 0) return null;
    final consumption = val - previous;
    if (consumption < 0) return null;
    final diffPct = previous > 0 ? (consumption / previous) * 100 : 0;
    if (diffPct.abs() > 50) {
      return 'الاستهلاك المحسوب (${consumption.toStringAsFixed(0)} kWh) يختلف بشكل كبير عن المعتاد — تحقق من الصورة قبل الإرسال.';
    }
    return null;
  }

  Future<void> _openCamera() async {
    final path = await context.push<String>('/readings/photo');
    if (path != null) setState(() => _imagePath = path);
  }

  Future<void> _submit(ReadingAssignment assignment) async {
    if (!_formKey.currentState!.validate()) return;

    final requiresPhoto = true; // customer-category readings always require a photo, mirroring ERP action_submit_review
    if (requiresPhoto && _imagePath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يجب تصوير العداد قبل الحفظ')),
      );
      return;
    }

    setState(() => _saving = true);
    final reading = MeterReading(
      id: _uuid.v4(),
      meterRemoteId: assignment.meter.remoteId,
      readingValue: double.parse(_valueCtrl.text),
      readingDate: DateTime.now(),
      category: ReadingCategory.customer,
      isEstimated: _estimated,
      remarks: _remarksCtrl.text.isEmpty ? null : _remarksCtrl.text,
      imageLocalPath: _imagePath,
      syncStatus: ReadingSyncStatus.draft,
    );

    final repo = ref.read(readingRepositoryProvider);
    await repo.saveDraft(reading);
    ref.read(syncEngineProvider).enqueue(reading);
    await ref.read(assignmentRepositoryProvider).markStatus(assignment.id, AssignmentStatus.read);

    if (mounted) {
      setState(() => _saving = false);
      context.pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ القراءة وإضافتها لطابور المزامنة')),
      );
    }
  }
}

class _ConsumptionHintBanner extends StatelessWidget {
  final String text;
  const _ConsumptionHintBanner({required this.text});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.orange.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
        ],
      ),
    );
  }
}

class _PhotoPicker extends StatelessWidget {
  final String? imagePath;
  final VoidCallback onCapture;
  final VoidCallback onClear;
  const _PhotoPicker({required this.imagePath, required this.onCapture, required this.onClear});

  @override
  Widget build(BuildContext context) {
    if (imagePath == null) {
      return OutlinedButton.icon(
        onPressed: onCapture,
        icon: const Icon(Icons.camera_alt_outlined),
        label: const Text('تصوير العداد (مطلوب)'),
      );
    }
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.file(File(imagePath!), height: 180, width: double.infinity, fit: BoxFit.cover),
        ),
        Positioned(
          top: 8,
          left: 8,
          child: IconButton.filledTonal(icon: const Icon(Icons.close), onPressed: onClear),
        ),
      ],
    );
  }
}
