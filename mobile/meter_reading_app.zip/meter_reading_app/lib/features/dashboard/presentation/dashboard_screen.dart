import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../shared/widgets/state_widgets.dart';
import '../../customers/domain/entities.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final assignments = ref.watch(assignmentsProvider(const AssignmentQuery()));
    final sync = ref.watch(syncSnapshotProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الرئيسية'),
        actions: [
          IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () => context.push('/settings')),
        ],
      ),
      body: assignments.when(
        loading: () => const LoadingState(),
        error: (e, _) => ErrorState(message: 'تعذر تحميل المهام: $e'),
        data: (list) {
          final total = list.length;
          final done = list.where((a) => a.status == AssignmentStatus.read).length;
          final pending = total - done;
          final offline = sync.value?.connectivity.name == 'offline';
          final pendingSync = (sync.value?.dataPipeline.pending ?? 0) + (sync.value?.imagePipeline.pending ?? 0);

          return Column(
            children: [
              OfflineBanner(offline: offline, pendingCount: pendingSync, onSyncNow: () => context.push('/sync')),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _ProgressCard(total: total, done: done, pending: pending),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: _QuickAction(
                            icon: Icons.list_alt_rounded,
                            label: 'قائمة المشتركين',
                            onTap: () => context.push('/customers'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: _QuickAction(
                            icon: Icons.sync_rounded,
                            label: 'مركز المزامنة',
                            onTap: () => context.push('/sync'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    Text('نصيحة اليوم', style: Theme.of(context).textTheme.titleSmall),
                    const SizedBox(height: 8),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            const Icon(Icons.photo_camera_outlined),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                'تأكد من وضوح أرقام العداد قبل تأكيد الصورة — الصور غير الواضحة تُعاد للمراجعة.',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ProgressCard extends StatelessWidget {
  final int total;
  final int done;
  final int pending;
  const _ProgressCard({required this.total, required this.done, required this.pending});

  @override
  Widget build(BuildContext context) {
    final progress = total == 0 ? 0.0 : done / total;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('تقدم القراءات هذا الشهر', style: Theme.of(context).textTheme.titleMedium),
                Text('$done / $total', style: Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(value: progress, minHeight: 10),
            ),
            const SizedBox(height: 12),
            Text('$pending عداد متبقٍّ لهذه الجولة', style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 8),
              Text(label, style: Theme.of(context).textTheme.labelLarge),
            ],
          ),
        ),
      ),
    );
  }
}
