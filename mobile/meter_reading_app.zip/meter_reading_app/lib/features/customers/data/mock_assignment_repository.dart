import 'dart:async';
import 'dart:math';

import '../domain/entities.dart';

/// Contract the UI/providers depend on. The real implementation will
/// fetch this from /api/v1/utility/reading/periods and a (future) route
/// assignment endpoint, then persist into the Assignments/Meters/Customers
/// Drift tables. Nothing above this interface needs to change when that
/// happens.
abstract class AssignmentRepository {
  Stream<List<ReadingAssignment>> watchAssignments({String? query, AssignmentStatus? filter});
  Future<ReadingAssignment?> lookupByMeterNumber(String meterNumber);
  Future<void> markStatus(String assignmentId, AssignmentStatus status);
}

class MockAssignmentRepository implements AssignmentRepository {
  final _controller = StreamController<List<ReadingAssignment>>.broadcast();
  late List<ReadingAssignment> _all;

  MockAssignmentRepository() {
    _all = _generateMockAssignments();
    _emit();
  }

  void _emit() => _controller.add(List.unmodifiable(_all));

  @override
  Stream<List<ReadingAssignment>> watchAssignments({String? query, AssignmentStatus? filter}) {
    return _controller.stream.map((list) {
      var filtered = list;
      if (filter != null) {
        filtered = filtered.where((a) => a.status == filter).toList();
      }
      if (query != null && query.trim().isNotEmpty) {
        final q = query.trim().toLowerCase();
        filtered = filtered
            .where((a) =>
                a.customer.name.toLowerCase().contains(q) ||
                a.customer.accountNumber.toLowerCase().contains(q) ||
                a.meter.meterNumber.toLowerCase().contains(q))
            .toList();
      }
      return filtered;
    });
  }

  @override
  Future<ReadingAssignment?> lookupByMeterNumber(String meterNumber) async {
    await Future.delayed(const Duration(milliseconds: 150));
    try {
      return _all.firstWhere((a) => a.meter.meterNumber == meterNumber);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<void> markStatus(String assignmentId, AssignmentStatus status) async {
    final idx = _all.indexWhere((a) => a.id == assignmentId);
    if (idx == -1) return;
    final a = _all[idx];
    _all[idx] = ReadingAssignment(id: a.id, meter: a.meter, customer: a.customer, status: status);
    _emit();
  }

  List<ReadingAssignment> _generateMockAssignments() {
    final names = [
      'محمد أحمد الحداد', 'فاطمة علي النعيمي', 'خالد سالم القحطاني', 'ليلى يوسف الشامي',
      'عبدالله حسين الزهراني', 'مريم عبدالرحمن العمري', 'سعيد ناصر البلوشي', 'هدى كريم السلمي',
      'ياسر فهد المطيري', 'نورة راشد الدوسري', 'طارق عمر الغامدي', 'سارة فيصل العتيبي',
    ];
    final rnd = Random(42);
    final list = <ReadingAssignment>[];
    for (var i = 0; i < names.length; i++) {
      final customer = Customer(
        remoteId: 1000 + i,
        accountNumber: 'ACC-${(100000 + i).toString()}',
        name: names[i],
        address: 'الحي ${i + 1}, شارع ${10 + i}',
        lastReadingDate: DateTime.now().subtract(Duration(days: 30 + rnd.nextInt(5))),
        lastReadingValue: (500 + rnd.nextInt(4000)).toDouble(),
      );
      final meter = Meter(
        remoteId: 2000 + i,
        meterNumber: 'MTR-${(1000 + i).toString()}',
        serialNumber: 'SN${(90000 + i).toString()}',
        customerRemoteId: customer.remoteId,
        paymentType: MeterPaymentType.postpaid,
        meterType: i % 5 == 0 ? 'Three Phase' : 'Single Phase',
      );
      list.add(ReadingAssignment(
        id: 'assign-$i',
        meter: meter,
        customer: customer,
        status: i < 3 ? AssignmentStatus.read : AssignmentStatus.pending,
      ));
    }
    return list;
  }

  void dispose() => _controller.close();
}
