import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../shared/widgets/state_widgets.dart';

class CustomerDetailScreen extends ConsumerWidget {
  final String assignmentId;
  const CustomerDetailScreen({super.key, required this.assignmentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final assignments = ref.watch(assignmentsProvider(const AssignmentQuery()));

    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل المشترك')),
      body: assignments.when(
        loading: () => const LoadingState(),
        error: (e, _) => ErrorState(message: 'خطأ: $e'),
        data: (list) {
          final match = list.where((a) => a.id == assignmentId);
          if (match.isEmpty) {
            return const EmptyState(icon: Icons.error_outline, title: 'العنصر غير موجود');
          }
          final a = match.first;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(a.customer.name, style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 4),
                      Text(a.customer.address ?? '—', style: Theme.of(context).textTheme.bodyMedium),
                      const Divider(height: 24),
                      _InfoRow(label: 'رقم الحساب', value: a.customer.accountNumber),
                      _InfoRow(label: 'رقم العداد', value: a.meter.meterNumber),
                      _InfoRow(label: 'نوع العداد', value: a.meter.meterType ?? '—'),
                      _InfoRow(
                        label: 'آخر قراءة',
                        value: a.customer.lastReadingValue != null
                            ? '${a.customer.lastReadingValue!.toStringAsFixed(0)} kWh'
                            : '—',
                      ),
                      _InfoRow(
                        label: 'تاريخ آخر قراءة',
                        value: a.customer.lastReadingDate != null
                            ? '${a.customer.lastReadingDate!.year}-${a.customer.lastReadingDate!.month.toString().padLeft(2, '0')}-${a.customer.lastReadingDate!.day.toString().padLeft(2, '0')}'
                            : '—',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                icon: const Icon(Icons.speed_rounded),
                label: const Text('بدء إدخال القراءة'),
                onPressed: () => context.push('/readings/new/${a.id}'),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: Theme.of(context).colorScheme.outline)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
