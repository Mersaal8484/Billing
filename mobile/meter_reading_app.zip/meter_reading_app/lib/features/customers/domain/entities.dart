/// Domain-level entities. These are what the UI and business logic work
/// with; they are intentionally decoupled from both the Drift row classes
/// (local storage detail) and any future Odoo JSON shape (remote detail).
/// Mapping between the three lives only in the data layer.

class Customer {
  final int remoteId;
  final String accountNumber;
  final String name;
  final String? address;
  final DateTime? lastReadingDate;
  final double? lastReadingValue;

  const Customer({
    required this.remoteId,
    required this.accountNumber,
    required this.name,
    this.address,
    this.lastReadingDate,
    this.lastReadingValue,
  });
}

enum MeterPaymentType { postpaid, prepaid, manual }

class Meter {
  final int remoteId;
  final String meterNumber;
  final String? serialNumber;
  final int customerRemoteId;
  final MeterPaymentType paymentType;
  final String? meterType;
  final bool isCouplingMeter;

  const Meter({
    required this.remoteId,
    required this.meterNumber,
    this.serialNumber,
    required this.customerRemoteId,
    required this.paymentType,
    this.meterType,
    this.isCouplingMeter = false,
  });
}

/// A single unit of field work: one meter, for one customer, for the
/// active billing period, with its current local status.
enum AssignmentStatus { pending, read, skipped }

class ReadingAssignment {
  final String id;
  final Meter meter;
  final Customer customer;
  final AssignmentStatus status;

  const ReadingAssignment({
    required this.id,
    required this.meter,
    required this.customer,
    required this.status,
  });
}
